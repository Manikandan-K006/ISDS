import { forwardRef } from 'react'
import { motion } from 'framer-motion'

/**
 * Button — primary interactive primitive.
 *
 * Variants:
 *  - "brand"   gradient, glow on hover (primary actions)
 *  - "outline" border only, fills on hover (secondary actions)
 *  - "ghost"   no border, subtle bg on hover (tertiary / icon buttons)
 *  - "danger"  destructive actions
 *
 * All colors come from CSS variables in tokens.css — never hardcode hex here.
 */
const variantClasses = {
  brand: 'btn-brand',
  outline:
    'bg-transparent border border-border-default text-text-primary hover:border-brand-500 hover:text-brand-500 rounded-md font-semibold',
  ghost:
    'bg-transparent text-text-secondary hover:bg-card-hover hover:text-text-primary rounded-md font-medium',
  danger:
    'bg-danger/10 text-danger border border-danger/30 hover:bg-danger/20 rounded-md font-semibold',
}

const sizeClasses = {
  sm: 'px-3 py-1.5 text-sm gap-1.5',
  md: 'px-4 py-2.5 text-base gap-2',
  lg: 'px-6 py-3.5 text-lg gap-2.5',
}

const Button = forwardRef(function Button(
  {
    variant = 'brand',
    size = 'md',
    loading = false,
    disabled = false,
    icon = null,
    iconPosition = 'left',
    className = '',
    children,
    ...props
  },
  ref
) {
  const isDisabled = disabled || loading

  return (
    <motion.button
      ref={ref}
      whileTap={!isDisabled ? { scale: 0.97 } : undefined}
      disabled={isDisabled}
      className={`
        inline-flex items-center justify-center font-body
        transition-opacity duration-150
        disabled:opacity-50 disabled:pointer-events-none
        ${variantClasses[variant]} ${sizeClasses[size]} ${className}
      `}
      {...props}
    >
      {loading ? (
        <span
          className="inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"
          aria-hidden="true"
        />
      ) : (
        <>
          {icon && iconPosition === 'left' && (
            <span className="inline-flex shrink-0">{icon}</span>
          )}
          <span>{children}</span>
          {icon && iconPosition === 'right' && (
            <span className="inline-flex shrink-0">{icon}</span>
          )}
        </>
      )}
    </motion.button>
  )
})

export default Button
