import { motion } from 'framer-motion'

/**
 * Card — the signature surface used everywhere: dashboard stat cards,
 * course cards, login card, settings panels.
 *
 * `interactive` adds the lift + brand-glow hover used for clickable cards
 * (course cards, nav cards) — leave it off for static containers
 * (e.g. a settings section) so things don't feel falsely clickable.
 */
export default function Card({
  children,
  interactive = false,
  padding = 'md',
  className = '',
  as: Component = 'div',
  ...props
}) {
  const paddingClasses = {
    none: '',
    sm: 'p-4',
    md: 'p-6',
    lg: 'p-8',
  }

  const MotionComponent = motion(Component)

  return (
    <MotionComponent
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
      className={`
        glass-card ${paddingClasses[padding]}
        ${interactive ? 'cursor-pointer' : ''}
        ${className}
      `}
      {...props}
    >
      {children}
    </MotionComponent>
  )
}

/** Sub-components for consistent card anatomy across the app */
Card.Header = function CardHeader({ children, className = '' }) {
  return (
    <div className={`flex items-center justify-between mb-4 ${className}`}>
      {children}
    </div>
  )
}

Card.Title = function CardTitle({ children, className = '' }) {
  return (
    <h3
      className={`font-display font-semibold text-text-primary text-xl ${className}`}
    >
      {children}
    </h3>
  )
}

Card.Description = function CardDescription({ children, className = '' }) {
  return (
    <p className={`font-body text-text-secondary text-sm mt-1 ${className}`}>
      {children}
    </p>
  )
}
