import { forwardRef, useId, useState } from 'react'

/**
 * Input — floating-label text field with icon support and focus glow.
 * Built specifically to satisfy the login-page brief:
 * "Floating labels / Icons / Focus glow / Smooth border animation"
 * but reused anywhere a text field appears (profile, course creation, etc.)
 */
const Input = forwardRef(function Input(
  { label, icon = null, error = null, type = 'text', className = '', ...props },
  ref
) {
  const id = useId()
  const [focused, setFocused] = useState(false)
  const [hasValue, setHasValue] = useState(false)

  const isFloating = focused || hasValue

  return (
    <div className={`relative ${className}`}>
      <div
        className={`
          relative flex items-center rounded-md border bg-card-solid
          transition-all duration-200
          ${error ? 'border-danger' : focused ? 'border-brand-500' : 'border-border-default'}
        `}
        style={{
          boxShadow: focused && !error ? 'var(--shadow-glow-brand)' : 'none',
        }}
      >
        {icon && (
          <span className="pl-3.5 text-text-tertiary shrink-0 flex items-center">
            {icon}
          </span>
        )}

        <input
          ref={ref}
          id={id}
          type={type}
          onFocus={(e) => {
            setFocused(true)
            props.onFocus?.(e)
          }}
          onBlur={(e) => {
            setFocused(false)
            props.onBlur?.(e)
          }}
          onChange={(e) => {
            setHasValue(e.target.value.length > 0)
            props.onChange?.(e)
          }}
          placeholder=" "
          className={`
            w-full bg-transparent outline-none font-body text-text-primary text-base
            pt-5 pb-2 px-3.5
            ${icon ? 'pl-2' : ''}
          `}
          {...props}
        />

        {label && (
          <label
            htmlFor={id}
            className={`
              absolute font-body pointer-events-none origin-left
              transition-all duration-200
              ${icon ? 'left-10' : 'left-3.5'}
              ${
                isFloating
                  ? 'top-2 text-xs text-brand-500'
                  : 'top-1/2 -translate-y-1/2 text-base text-text-tertiary'
              }
            `}
          >
            {label}
          </label>
        )}
      </div>

      {error && (
        <p className="mt-1.5 text-xs text-danger font-body">{error}</p>
      )}
    </div>
  )
})

export default Input
